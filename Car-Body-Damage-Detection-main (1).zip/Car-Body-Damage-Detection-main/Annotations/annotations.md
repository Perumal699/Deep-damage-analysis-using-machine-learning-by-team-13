## Create your own dataset

1.  Gather the images in one folder.
2.  Anotate in VOTT via [this guide](https://learn.microsoft.com/en-us/dotnet/machine-learning/how-to-guides/label-images-for-object-detection-using-vott).
4.  Edit export settings to Pascal VOC. 
5.  Click ctrl+e to export the xml files.
6.  Convert annotation files to Yolo formate via [XmlToTxt](https://github.com/Isabek/XmlToTxt).
